﻿namespace Calculadora_Projeto
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.bPonto = new System.Windows.Forms.Button();
            this.bCE = new System.Windows.Forms.Button();
            this.bMultiplicar = new System.Windows.Forms.Button();
            this.bSoma = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.bSub = new System.Windows.Forms.Button();
            this.bDividir = new System.Windows.Forms.Button();
            this.bIgual = new System.Windows.Forms.Button();
            this.lbl2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(12, 22);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(70, 25);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "label1";
            // 
            // txt1
            // 
            this.txt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1.Location = new System.Drawing.Point(15, 54);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(272, 31);
            this.txt1.TabIndex = 1;
            // 
            // b7
            // 
            this.b7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(17, 104);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(63, 57);
            this.b7.TabIndex = 2;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // b8
            // 
            this.b8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(86, 104);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(63, 57);
            this.b8.TabIndex = 3;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b9
            // 
            this.b9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(155, 104);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(63, 57);
            this.b9.TabIndex = 4;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // b4
            // 
            this.b4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(17, 167);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(63, 57);
            this.b4.TabIndex = 5;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b5
            // 
            this.b5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(86, 167);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(63, 57);
            this.b5.TabIndex = 6;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b6
            // 
            this.b6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(155, 167);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(63, 57);
            this.b6.TabIndex = 7;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // b1
            // 
            this.b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(17, 230);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(63, 57);
            this.b1.TabIndex = 8;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // b2
            // 
            this.b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(86, 230);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(63, 57);
            this.b2.TabIndex = 9;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // b3
            // 
            this.b3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(155, 230);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(63, 57);
            this.b3.TabIndex = 10;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // bPonto
            // 
            this.bPonto.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bPonto.Location = new System.Drawing.Point(224, 104);
            this.bPonto.Name = "bPonto";
            this.bPonto.Size = new System.Drawing.Size(63, 57);
            this.bPonto.TabIndex = 11;
            this.bPonto.Text = ".";
            this.bPonto.UseVisualStyleBackColor = true;
            this.bPonto.Click += new System.EventHandler(this.bPonto_Click);
            // 
            // bCE
            // 
            this.bCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bCE.Location = new System.Drawing.Point(224, 167);
            this.bCE.Name = "bCE";
            this.bCE.Size = new System.Drawing.Size(63, 57);
            this.bCE.TabIndex = 12;
            this.bCE.Text = "CE";
            this.bCE.UseVisualStyleBackColor = true;
            this.bCE.Click += new System.EventHandler(this.bCE_Click);
            // 
            // bMultiplicar
            // 
            this.bMultiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bMultiplicar.Location = new System.Drawing.Point(224, 230);
            this.bMultiplicar.Name = "bMultiplicar";
            this.bMultiplicar.Size = new System.Drawing.Size(63, 57);
            this.bMultiplicar.TabIndex = 13;
            this.bMultiplicar.Text = "*";
            this.bMultiplicar.UseVisualStyleBackColor = true;
            this.bMultiplicar.Click += new System.EventHandler(this.bMultiplicar_Click);
            // 
            // bSoma
            // 
            this.bSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bSoma.Location = new System.Drawing.Point(17, 293);
            this.bSoma.Name = "bSoma";
            this.bSoma.Size = new System.Drawing.Size(63, 57);
            this.bSoma.TabIndex = 14;
            this.bSoma.Text = "+";
            this.bSoma.UseVisualStyleBackColor = true;
            this.bSoma.Click += new System.EventHandler(this.bSoma_Click);
            // 
            // b0
            // 
            this.b0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b0.Location = new System.Drawing.Point(86, 293);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(63, 57);
            this.b0.TabIndex = 15;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.b0_Click);
            // 
            // bSub
            // 
            this.bSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bSub.Location = new System.Drawing.Point(155, 293);
            this.bSub.Name = "bSub";
            this.bSub.Size = new System.Drawing.Size(63, 57);
            this.bSub.TabIndex = 16;
            this.bSub.Text = "-";
            this.bSub.UseVisualStyleBackColor = true;
            this.bSub.Click += new System.EventHandler(this.bSub_Click);
            // 
            // bDividir
            // 
            this.bDividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bDividir.Location = new System.Drawing.Point(224, 293);
            this.bDividir.Name = "bDividir";
            this.bDividir.Size = new System.Drawing.Size(63, 57);
            this.bDividir.TabIndex = 17;
            this.bDividir.Text = "/";
            this.bDividir.UseVisualStyleBackColor = true;
            this.bDividir.Click += new System.EventHandler(this.bDividir_Click);
            // 
            // bIgual
            // 
            this.bIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bIgual.Location = new System.Drawing.Point(17, 356);
            this.bIgual.Name = "bIgual";
            this.bIgual.Size = new System.Drawing.Size(270, 57);
            this.bIgual.TabIndex = 18;
            this.bIgual.Text = "=";
            this.bIgual.UseVisualStyleBackColor = true;
            this.bIgual.Click += new System.EventHandler(this.bIgual_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(219, 22);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(70, 25);
            this.lbl2.TabIndex = 19;
            this.lbl2.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 424);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.bIgual);
            this.Controls.Add(this.bDividir);
            this.Controls.Add(this.bSub);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.bSoma);
            this.Controls.Add(this.bMultiplicar);
            this.Controls.Add(this.bCE);
            this.Controls.Add(this.bPonto);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button bPonto;
        private System.Windows.Forms.Button bCE;
        private System.Windows.Forms.Button bMultiplicar;
        private System.Windows.Forms.Button bSoma;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button bSub;
        private System.Windows.Forms.Button bDividir;
        private System.Windows.Forms.Button bIgual;
        private System.Windows.Forms.Label lbl2;
    }
}

